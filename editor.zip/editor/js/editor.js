$(function(){

    //hljs.initHighlightingOnLoad();
    $('.editor').append('<pre class="ed ew abs index-10" contenteditable="true"></pre>');
    $('.editor').append('<pre class="vd ew abs " contenteditable="true"></pre>');

    $('.editor .vd').click(function(){
        $('.editor .ed').focus();
    });

    $('.editor .ed').on('keyup',function(){

        var a=getSelection();
        var range=getSelection().getRangeAt(0);
        var pos=range.startOffset;


        $('.editor .vd').html('<code>'+$('.editor .ed').html()+'</code>');

        $('pre code').each(function(i, block) {
            hljs.highlightBlock(block);
        });
        a.removeAllRanges();
                a.addRange(range);

        var win=window.getSelection()




        console.log(pos);
        var ed=document.getElementsByClassName('ed')[0];
        ed.focus();
        range.setStart(range.startContainer,pos);
    });


})
